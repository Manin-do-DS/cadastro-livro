 Modelo de biblioteca digital com cadastro e login de usuarios, e, com implementação de cadastro de livros e manipulação de CRUD.
