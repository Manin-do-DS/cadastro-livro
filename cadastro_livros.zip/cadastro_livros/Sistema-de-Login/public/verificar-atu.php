<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualizar conta</title>
</head>
<body>
<form method="post" action="process-verifica.php">
    <label for="email">Email: </label>
    <input type="email" id="email" name="email" required>
    <br>
    <label for="senha">Senha: </label>
    <input type="password" id="senha" name="senha" required>
    <br>
    <button type="submit">Entrar para mudança</button>
</form>


</body>
</html>
